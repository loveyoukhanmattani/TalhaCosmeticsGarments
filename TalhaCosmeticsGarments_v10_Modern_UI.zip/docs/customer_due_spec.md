# Customer & Due/Payment System — V5

## Customer
Fields:
- Customer ID
- Name
- Mobile
- Address (optional)
- Opening Due
- Notes

## Due
- Invoice-linked outstanding balance
- Total purchases
- Total paid
- Current due
- Due status

## Payment
Fields:
- Payment ID
- Customer ID
- Date/time
- Amount
- Method (Cash / Bank / Other)
- Note

## Rules
- Cash sale: due remains unchanged.
- Credit sale: invoice total increases customer due.
- Receiving a payment decreases due.
- Reprinting an invoice never changes stock or customer balance.
- Deleting/editing financial records should require confirmation.

## Dashboard
Show:
- Total Sales
- Total Due
- Payments Received
- Stock Value
- Low Stock Count
