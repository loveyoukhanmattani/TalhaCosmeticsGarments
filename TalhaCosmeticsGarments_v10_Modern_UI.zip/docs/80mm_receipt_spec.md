# Talha Cosmetics & Garments — 80mm Thermal Receipt

Paper width: 80mm
Recommended printable width: 72–76mm
Logical receipt width: 576px at 203 DPI
Text: black on white, no gradients
Recommended font sizes: 24px title, 18px body, 16px footer

Receipt layout:
1. Store name: TALHA COSMETICS & GARMENTS
2. Date / time
3. Invoice number
4. Product / Qty / Price / Amount
5. Subtotal
6. Discount
7. Grand Total
8. Paid / Change
9. Thank you message

Sales History:
- Invoice number
- Date/time
- Items
- Total
- Payment status
- Reprint/share action

The receipt should be generated from the same sale record used to reduce stock, so reprints never alter inventory.
