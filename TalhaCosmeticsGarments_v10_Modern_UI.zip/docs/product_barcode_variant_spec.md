# Product, Barcode & Variant System — V8

## Product
Common fields:
- Product ID
- Name
- Category (Cosmetics / Garments)
- Brand
- Barcode
- SKU
- Purchase Price
- Retail Price
- Wholesale Price
- Current Stock
- Reorder Level
- Product Image
- Active/Inactive

## Garments variants
Optional variants per product:
- Size: XS, S, M, L, XL, XXL, custom
- Color
- Design/style
- Variant SKU
- Variant barcode
- Variant stock
- Variant prices

A garment product's stock is tracked at variant level when variants exist.

## Cosmetics
Optional:
- Shade
- Size/Volume
- Batch No.
- Expiry Date

## Barcode
- Scan barcode to search/select a product or variant.
- If a scanned barcode matches one item, open it directly.
- If it is unknown during a sale, offer Add Product.
- Barcode generation should be available for products without a barcode.
- Re-scanning must not duplicate cart lines; it increases quantity for the existing line.

## Images
- Add image from device gallery/camera.
- Show thumbnail in product list and product details.
- Image is for identification/catalogue use and is not required for billing.

## Data templates
