# Supplier & Purchase / Stock-In System — V6

## Supplier
Fields:
- Supplier ID
- Name
- Mobile
- Address (optional)
- Opening Payable
- Notes

## Purchase
Fields:
- Purchase ID / Bill No.
- Supplier
- Date/time
- Items
- Purchase price
- Quantity
- Discount
- Total
- Paid
- Due
- Payment method

## Stock-In rules
- Posting a purchase increases product stock.
- Purchase price can update the product's latest cost.
- Editing a posted purchase must reverse the old stock movement before applying the new one.
- Deleting a posted purchase requires confirmation and reverses its stock movement.
- A purchase does not create a customer due; it creates supplier payable when unpaid.

## Supplier payments
- Record payment against supplier payable.
- Show supplier total purchases, total paid and current payable.
- Keep payment history with date/time and method.

## Reports
- Purchase history
- Supplier payable
- Product purchase-cost history
- Stock-in history
- Daily/monthly purchase totals
