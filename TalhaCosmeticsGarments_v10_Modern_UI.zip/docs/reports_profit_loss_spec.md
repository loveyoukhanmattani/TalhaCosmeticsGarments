# Reports, Profit/Loss & Dashboard — V7

## Dashboard
Show:
- Today's sales
- Today's purchases
- Today's profit
- Total receivable (customer due)
- Total payable (supplier due)
- Stock value
- Low-stock products
- Number of invoices

## Sales reports
Filters:
- Today
- Yesterday
- This week
- This month
- Custom date range

Columns:
- Invoice
- Date/time
- Customer
- Total
- Paid
- Due
- Gross profit

## Purchase reports
- Purchase bill
- Supplier
- Date/time
- Total
- Paid
- Due

## Profit/Loss
For each sale:
Gross Profit = Selling Amount - Cost Amount - Sale Discount Allocation

Period profit:
Total Gross Profit - Other Expenses

Expense fields:
- Expense ID
- Date/time
- Category
- Description
- Amount
- Payment method

## Important accounting rule
Profit should use the product cost recorded at the time of sale, not today's purchase price. Invoice reprints and report viewing must never alter stock or financial balances.

## Export
- CSV export for sales
- CSV export for purchases
- CSV export for expenses
- Date-filtered report export
