# V9 — Backup, Security & Store Settings

## Backup
- Manual full-data backup to JSON.
- Restore from a selected backup.
- CSV export for products, sales, purchases, customers, suppliers, payments and expenses.
- Backup should include a schema/version number.
- Restore must validate the backup before replacing data.
- Never overwrite current data without confirmation.

## App Lock
- Optional 4–6 digit PIN.
- Lock app on launch/resume when enabled.
- PIN should be stored securely (hash/secure storage), never as plain text.
- Provide change PIN and disable PIN options after successful authentication.

## Store Settings
- Store name: Talha Cosmetics & Garments
- Currency: PKR (₨)
- Phone / WhatsApp
- Address
- Receipt footer
- Optional logo
- Default retail/wholesale sale mode
- Default receipt paper: 80mm

## Data safety
- Destructive actions require confirmation.
- Restore/reset actions show a clear warning.
- Financial records should keep their original timestamps.
- Exported backups should be shareable/savable by the user.

## Theme
- System default
- Light
- Dark
