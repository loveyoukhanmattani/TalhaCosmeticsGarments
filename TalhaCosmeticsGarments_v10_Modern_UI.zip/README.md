

## V4 additions
- 80mm thermal receipt specification
- Sales history CSV template
- Receipt reprint/share design guidance
- Receipt generation must not change stock on reprint


## V5 additions
- Customer management specification
- Customer-linked due balances
- Payment receiving/history specification
- Dashboard financial metrics
- CSV templates for customers and payments


## V6 additions
- Supplier management
- Purchase / stock-in specification
- Supplier payable and payment history
- Purchase and stock-in report definitions
- CSV templates for suppliers, purchases, purchase items and supplier payments


## V7 additions
- Sales and purchase reports
- Date-range filtering
- Gross profit and period profit/loss definitions
- Expense tracking template
- Dashboard KPI definitions
- CSV export templates


## V8 additions
- Barcode scanning/search behavior
- Product image fields
- Garments size/color/style variants
- Cosmetics shade/volume/batch/expiry fields
- Variant-level stock and barcode support
- Product and variant CSV templates


## V9 additions
- Full JSON backup/restore specification
- CSV export coverage
- Secure optional app PIN
- Store and receipt settings
- PKR currency defaults
- Theme settings
- Destructive-action confirmation rules
