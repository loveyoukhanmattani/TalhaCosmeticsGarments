package com.talha.cosmeticsgarments

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    data class Product(var name:String,var category:String,var purchase:Double,var price:Double,var wholesale:Double,var stock:Int,var reorder:Int,var barcode:String)
    data class CartLine(val productIndex:Int,var qty:Int)
    private val products=mutableListOf<Product>()
    private val cart=mutableListOf<CartLine>()
    private lateinit var root:LinearLayout
    private val prefs by lazy{getSharedPreferences("inventory",MODE_PRIVATE)}
    private val pickFile=501

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);load();showDashboard()}
    private fun text(s:String,size:Float=16f)=TextView(this).apply{
        text=s; textSize=size; setTextColor(Color.rgb(32,35,42)); setPadding(4,6,4,6)
    }
    private fun base(title:String):LinearLayout{
        root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL; setPadding(20,22,20,16); setBackgroundColor(Color.rgb(248,249,251))
        }
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val heading=text(title,24f).apply{setTypeface(null,android.graphics.Typeface.BOLD)}
        bar.addView(heading,LinearLayout.LayoutParams(0,60,1f))
        setContentView(root); root.addView(bar); return root
    }
    private fun btn(label:String,action:()->Unit)=Button(this).apply{
        text=label; textSize=15f; setAllCaps(false); setOnClickListener{action()}
        root.addView(this,LinearLayout.LayoutParams(-1,56).apply{bottomMargin=10})
    }
    private fun field(hint:String,value:String="")=EditText(this).apply{this.hint=hint;setText(value);inputType=InputType.TYPE_CLASS_TEXT;root.addView(this,LinearLayout.LayoutParams(-1,55).apply{bottomMargin=7})}
    private fun numField(hint:String,value:String="")=EditText(this).apply{this.hint=hint;setText(value);inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;root.addView(this,LinearLayout.LayoutParams(-1,55).apply{bottomMargin=7})}
    private fun card(title:String,value:String,action:()->Unit):TextView{
        return TextView(this).apply{
            text="$title\n$value"; textSize=16f; setTextColor(Color.rgb(30,33,40)); setPadding(18,14,18,14); setOnClickListener{action()}
            setBackgroundColor(Color.WHITE)
            root.addView(this,LinearLayout.LayoutParams(-1,82).apply{bottomMargin=10})
        }
    }

    private fun showDashboard(){
        base("Talha Cosmetics & Garments")
        root.addView(text("Simple • Fast • Offline",14f))
        val stats=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(stats)
        fun stat(label:String,value:String){stats.addView(TextView(this).apply{text="$label  $value";textSize=15f;setPadding(14,10,14,10);setBackgroundColor(Color.WHITE);setTextColor(Color.DKGRAY)},LinearLayout.LayoutParams(-1,48).apply{bottomMargin=4})}
        stat("Products",products.size.toString()); stat("Total Stock","${products.sumOf{it.stock}} units"); stat("Low Stock",products.count{it.stock<=it.reorder}.toString())
        root.addView(text("Quick Actions",19f).apply{setTypeface(null,android.graphics.Typeface.BOLD);setPadding(4,16,4,8)})
        card("🧾  New Sale","Create bill and receipt"){showSales()}
        card("📦  Products","Search, add and manage products"){showProducts()}
        card("➕  Add Product","Add cosmetics or garments"){showAddProduct()}
        card("🔄  Stock","Stock in / stock out"){showStock()}
        card("💾  Backup","Backup and restore your data"){showBackup()}
    }

    private fun showProducts(){base("Products");val search=EditText(this).apply{hint="Search product / barcode"};root.addView(search,LinearLayout.LayoutParams(-1,55));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(list);fun render(){list.removeAllViews();val q=search.text.toString().trim().lowercase();products.filter{q.isEmpty()||it.name.lowercase().contains(q)||it.barcode.contains(q)}.forEach{p->val i=products.indexOf(p);val t=text("${p.name}\n${p.category} • Stock: ${p.stock} • Retail: Rs ${money(p.price)}",16f);t.setOnClickListener{editProduct(i)};list.addView(t);list.addView(View(this).apply{setBackgroundColor(0xffdddddd.toInt())},LinearLayout.LayoutParams(-1,1))}};search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?){}});render();btn("← Dashboard"){showDashboard()}}

    private fun showAddProduct(existing:Int=-1){base(if(existing<0)"Add Product" else "Edit Product");val old=if(existing>=0)products[existing] else null;val name=field("Product name",old?.name? : "");val cat=field("Category: Cosmetics or Garments",old?.category?:"Cosmetics");val purchase=numField("Purchase price",old?.purchase?.toString()? : "");val price=numField("Retail price",old?.price?.toString()? : "");val wholesale=numField("Wholesale price",old?.wholesale?.toString()? : "");val stock=numField("Stock",old?.stock?.toString()? : "0");val reorder=numField("Reorder level",old?.reorder?.toString()? : "5");val barcode=field("Barcode (optional)",old?.barcode?:"");btn("Save Product"){if(name.text.toString().trim().isEmpty()){toast("Product name required");return@btn};val p=Product(name.text.toString().trim(),cat.text.toString().trim(),purchase.text.toString().toDoubleOrNull()?:0.0,price.text.toString().toDoubleOrNull()?:0.0,wholesale.text.toString().toDoubleOrNull()?:0.0,stock.text.toString().toIntOrNull()?:0,reorder.text.toString().toIntOrNull()?:5,barcode.text.toString().trim());if(existing<0)products.add(p) else products[existing]=p;save();toast("Saved");showProducts()};if(existing>=0)btn("Delete Product"){products.removeAt(existing);save();showProducts()};btn("Cancel"){showProducts()}}
    private fun editProduct(i:Int)=showAddProduct(i)

    private fun showStock(){base("Stock In / Stock Out");if(products.isEmpty()){root.addView(text("Add products first."));btn("Add Product"){showAddProduct()};btn("← Dashboard"){showDashboard()};return};val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,products.map{it.name});root.addView(sp);val qty=numField("Quantity","1");val mode=Spinner(this);mode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Stock In","Stock Out"));root.addView(mode);btn("Apply"){val i=sp.selectedItemPosition;val n=qty.text.toString().toIntOrNull()?:0;if(n<=0){toast("Enter quantity");return@btn};if(mode.selectedItemPosition==0)products[i].stock+=n else{if(n>products[i].stock){toast("Not enough stock");return@btn};products[i].stock-=n};save();toast("Stock updated");showStock()};btn("← Dashboard"){showDashboard()}}

    private fun showSales(){cart.clear();base("New Sale / Billing");if(products.isEmpty()){root.addView(text("Add products first."));btn("Add Product"){showAddProduct()};btn("← Dashboard"){showDashboard()};return};val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,products.map{"${it.name} (stock ${it.stock})"});root.addView(sp);val qty=numField("Quantity","1");val add=Button(this).apply{text="Add to Cart";setOnClickListener{val i=sp.selectedItemPosition;val n=qty.text.toString().toIntOrNull()?:0;if(n<=0){toast("Enter quantity");return@setOnClickListener};val already=cart.find{it.productIndex==i}?.qty?:0;if(n+already>products[i].stock){toast("Not enough stock");return@setOnClickListener};cart.removeAll{false};val line=cart.find{it.productIndex==i};if(line==null)cart.add(CartLine(i,n))else line.qty+=n;renderSale()}};root.addView(add,LinearLayout.LayoutParams(-1,58).apply{bottomMargin=10});renderSale()}

    private fun renderSale(){val old=root.findViewWithTag<View>("sale_list");if(old!=null)root.removeView(old);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="sale_list"};root.addView(list,root.indexOfChild(root.findViewWithTag("sale_actions")));var total=0.0;cart.forEach{line->val p=products[line.productIndex];val sub=p.price*line.qty;total+=sub;list.addView(text("${p.name} × ${line.qty} = Rs ${money(sub)}",16f))};list.addView(text("TOTAL: Rs ${money(total)}",21f));val actions=root.findViewWithTag<LinearLayout>("sale_actions");if(actions==null){val a=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="sale_actions"};root.addView(a);val complete=Button(this).apply{text="Complete Sale & Receipt";setOnClickListener{completeSale()}};a.addView(complete,LinearLayout.LayoutParams(-1,58).apply{bottomMargin=10});val clear=Button(this).apply{text="Clear Cart";setOnClickListener{cart.clear();renderSale()}};a.addView(clear,LinearLayout.LayoutParams(-1,58).apply{bottomMargin=10});val back=Button(this).apply{text="← Dashboard";setOnClickListener{showDashboard()}};a.addView(back,LinearLayout.LayoutParams(-1,58))}}

    private fun completeSale(){if(cart.isEmpty()){toast("Cart is empty");return};var total=0.0;val receipt=StringBuilder();receipt.append("TALHA COSMETICS & GARMENTS\n");receipt.append("SALE RECEIPT\n");receipt.append("${SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(Date())}\n");receipt.append("------------------------------\n");cart.forEach{line->val p=products[line.productIndex];val sub=p.price*line.qty;total+=sub;receipt.append("${p.name}\n${line.qty} x Rs ${money(p.price)} = Rs ${money(sub)}\n");p.stock-=line.qty};receipt.append("------------------------------\nTOTAL: Rs ${money(total)}\nThank you!\n");save();cart.clear();val intent=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,receipt.toString())};startActivity(Intent.createChooser(intent,"Share / Print Receipt"));showDashboard()}

    private fun showBackup(){base("Backup & Restore");root.addView(text("Create a JSON backup or restore one later.",16f));btn("Export Backup"){exportBackup()};btn("Restore Backup"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE)},pickFile)};btn("← Dashboard"){showDashboard()}}
    private fun exportBackup(){val a=JSONArray();products.forEach{p->a.put(productJson(p))};val i=Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_TEXT,a.toString(2))};startActivity(Intent.createChooser(i,"Share backup"))}
    private fun productJson(p:Product)=JSONObject().apply{put("name",p.name);put("category",p.category);put("purchase",p.purchase);put("price",p.price);put("wholesale",p.wholesale);put("stock",p.stock);put("reorder",p.reorder);put("barcode",p.barcode)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==pickFile&&resultCode==RESULT_OK){try{val s=contentResolver.openInputStream(data!!.data!!)?.bufferedReader()?.readText()? : "";val a=JSONArray(s);products.clear();for(j in 0 until a.length()){val o=a.getJSONObject(j);products.add(Product(o.optString("name"),o.optString("category"),o.optDouble("purchase"),o.optDouble("price"),o.optDouble("wholesale"),o.optInt("stock"),o.optInt("reorder",5),o.optString("barcode")))};save();toast("Backup restored");showDashboard()}catch(e:Exception){toast("Invalid backup file")}}}
    private fun save(){val a=JSONArray();products.forEach{a.put(productJson(it))};prefs.edit().putString("products",a.toString()).apply()}
    private fun load(){try{val a=JSONArray(prefs.getString("products","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);products.add(Product(o.optString("name"),o.optString("category"),o.optDouble("purchase"),o.optDouble("price"),o.optDouble("wholesale"),o.optInt("stock"),o.optInt("reorder",5),o.optString("barcode")))}}catch(_:Exception){}}
    private fun money(v:Double)=String.format(Locale.US,"%.0f",v);private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
